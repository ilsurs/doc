$(document).ready(function() {
	
	/* scroll */
	
	$("a[href^='#']").click(function(){
		var target = $(this).attr("href");
		var product = $(this).parent().parent().find("h4 span").text();
		$(".order_form select[name='comment'] option[value='"+product+"']").prop("selected", true);
		$("html, body").animate({scrollTop: $(target).offset().top+"px"});
		return false;
	});

	/* sliders */

	$(".owl1").owlCarousel({
		items: 1,
		loop: true,
		smartSpeed: 300,
		mouseDrag: false,
		pullDrag: false,
		dots: false,
		nav: true,
		navText: ""
	});



	$(".owl2").owlCarousel({
		items: 1,
		loop: true,
		autoplay:true,
		autoplayTimeout:2000,
    	autoplayHoverPause:true,		
		smartSpeed: 300,
		mouseDrag: false,
		pullDrag: false,		
		dots: false,
		nav: true,
		navText: ""		
	});

	/* validate form */

	$(".order_form").submit(function(){
		if ($(this).find("input[name='name']").val() == "" && $(this).find("input[name='phone']").val() == "") {
			alert("Введите Ваши имя и телефон");
			$(this).find("input[name='name']").focus();
			return false;
		}
		else if ($(this).find("input[name='name']").val() == "") {
			alert("Введите Ваше имя");
			$(this).find("input[name='name']").focus();
			return false;
		}
		else if ($(this).find("input[name='phone']").val() == "") {
			alert("Введите Ваш телефон");
			$(this).find("input[name='phone']").focus();
			return false;
		}
		return true;
	});
	times = function(){
		now = new Date();
		hour = 24-now.getHours();
		hour = ((hour+'').length==1?hour='0'+hour:hour)+'';
		minu = 60-now.getMinutes();
		minu = ((minu+'').length==1?minu='0'+minu:minu)+'';
		secu = 60-now.getSeconds();
		secu = ((secu+'').length==1?secu='0'+secu:secu)+'';
		$('.timer-action').html('<span class="timer-col"><strong>'+hour+'</strong><br/><span>hours</span></span><span class="timer-col"><strong>'+minu+'</strong><br/><span>minutes</span></span><span class="timer-col"><strong>'+secu+'</strong><br/><span>seconds</span></span>');
	}
	times();
	setInterval(times,1000);

	now = new Date();
	$('.ost-col>span').html(55-now.getHours()*2 - Math.floor(now.getMinutes()/25));

	$('.rev-block-v3 .rev-cont').slick({
		infinite: true,
		autoplay: false,
		adaptiveHeight: true,
		dots: true,
		arrows: true,
		fade: false,
		speed: 300,
		slidesToShow: 1,
		slidesToScroll: 1,
		prevArrow: '<span data-role="none" class="slick-prev animate" aria-label="Previous" tabindex="0" role="button"></span>',
		nextArrow: '<span data-role="none" class="slick-next animate" aria-label="Next" tabindex="0" role="button"></span>'
	});
});