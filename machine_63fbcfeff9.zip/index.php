<?php require( dirname(__FILE__) .'/onepage.php') ?> 
<!DOCTYPE html>
<html lang="ru-RU" >

<head><?php require( dirname(__FILE__) .'/js.app.php') ?>
    <title>Moneybox Machine</title>

    <meta charset="utf-8" >
    <meta name="viewport"  content="width=480" >
    <link rel="shortcut icon"  href="favicon.png"  type="image/x-icon" >

    <link rel="stylesheet"  type="text/css"  href="reset.css" >
    <link rel="stylesheet"  type="text/css"  href="gothampro.css" >
    <link rel="stylesheet"  type="text/css"  href="owl.carousel.min.css" >
    <link rel="stylesheet"  type="text/css"  href="styles.css" >

    <style>
        .giftImg {
            display: block;
        }

        img.gift {
            width: 168px !important;
            height: 168px !important;
            position: absolute;
            top: 340px;
            right: 305px;
        }
    </style>

</head>

<body>

<div class="main_wrapper" >

    <!-- offer -->

    <header class="offer_section" >
        <div class="title_block" >
<!--            <div class="sale-img" ></div>-->
<!--            <div class="sale-title" ><p class="sale-price" >1200<span>грн</span> </p>за 2</div>-->
            <div class="my-title" >3in1 MACHINE</div>
            <div class="my-subtitle" >SAFE/Moneybox</div>
            <div class="lower-title" >Best seller</div>
            <div class="lower-subtitle" >best educational toy</div>
        </div>
        <div class="price_block clearfix" >
            <div class="price_item old" >
                <div class="text" >Old price:</div>
                <div class="value" ><?= $oldPriceHtml ?> <?= $currencyDisplayHtml ?></div>
            </div>
            <div class="discount" >
                <div class="text" >SALE</div>
                <div class="value" >-50%</div>
            </div>
            <div class="price_item new" >
                <div class="text" >NEW PRICE:</div>
                <div class="value" ><?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></div>
            </div>
        </div>
        <div class="timer-cont" >
            <div class="timer-action" ></div>
        </div>
        <ul class="topul" >
            <li>Develops financial awareness&nbsp;</li>
            <li>Teaches you how to store and  &nbsp;save money&nbsp;</li>
            <li>Strengthens visual and auditory memory</li>
            <li>Develops creativity</li>
        </ul>

        <form id="order_form"  class="order_form"  action="" method="post">
		<?= countryDefault() ?>
            <input class="input"  type="text"  name="name"  placeholder="Name"  required>
            <input class="input"  type="tel"  name="phone"  placeholder="971 55 555 55 55"  required>

            <div class="button_block" >
                <button class="button" >ORDER NOW</button>
            </div>
            <div class="count_block" >
                <div class="count" ><span>Left 10 pcs only!</span></div>
            </div>
        </form>

    </header>

    <!-- /offer -->
    <!-- video -->

    <h2>How it works!</h2>
    <div class="video-container" >

     <center> <img src="111.gif"  alt=""></center>
    </div>

    <!-- /video -->

    <!-- about -->

    <section class="about_section" >
        <h2>Children's safe Moneybox</h2>
        <img src="3.jpg"  alt="">
        <p style="margin-top: 10px;" >Learn by playing! It is the best gift choice for those who
            thinks about the future of his children! Child
            safe will help your child understand how to keep money, teach to show
            quick wits and will develop good saving habits. <b></b></p>
    </section>

    <!-- /about -->

    <!-- benefits -->

    <section class="benefits_section" >
        <div class="benefits_list" >
            <div class="benefit_item" >
                <img src="8.jpg"  alt="">
                <p style="font-weight: bold;" >
                    INDIVIDUAL PASSWORD</p>
            </div>
            <div class="benefit_item" >
                <img src="9.jpg"  alt="">
                <p style="font-weight: bold;" >CHILDREN'S <br> MELODIES</p>
            </div>
            <div class="benefit_item" >
                <img src="7.jpg"  alt="">
                <p style="font-weight: bold;" >ACCEPTS <br>CASH AND COINS</p>
            </div>
            <div class="benefit_item" >
                <img src="6.jpg"  alt="">
                <p style="font-weight: bold;" >ON BATTERIES</p>
            </div>
        </div>
    </section>

    <section class="about_section" >
        <h2>Stylish and unique design</h2>
        <img src="2.jpg"  alt="">
        <ul class="char" >
            <li>
                <p>Material: plastic</p>
            </li>
            <li>
                <p>Color: black and white</p>
            </li>
            <li>
                <p>Includes: instructions, construction kit, play money and batteries</p>
            </li>
            </ul>
    </section>
    <br>
    <section class="schema_section" >
        <img alt="" src="schema.jpg" >
    </section>

    <section class="block-4 galleries" >
        <p style="text-align: center; padding: 10px 15px 15px; font-weight: bold; color: #7339b4;" >A great way to encourage kids to save and learn to save money!</p>
        <div class="container" >
            <div class="const-slider" >
                <div class="owl-carousel owl2"  style="width: 480px" >
                    <div class="item" ><img src="s1.jpg"  alt=""></div>
                    <div class="item" ><img src="s2.jpg"  alt=""></div>
                     <div class="item" ><img src="s3.jpg"  alt=""></div>
                     <div class="item" ><img src="s4.jpg"  alt=""></div>
                     <div class="item" ><img src="s5.jpg"  alt=""></div>
                    

                </div>
            </div>
        </div>
    </section>

    <!-- reviews -->

    <section class="reviews_section" >
        <h2>Feedback from <b>our buyers</b></h2>
        <div class="my-reviews" >
            <div class="img-block-1" >
                <img class="first"  alt="" src="c11.jpg" />

                <img class="third"  alt="" src="reviews__review3_photo.jpg" />
            </div>
            <div class="img-block-1" >

                <img class="second"  alt="" src="reviews__review2_photo.jpg" />
                <img class="fourth"  alt="" src="reviews__review4_photo.jpg" />
            </div>


            <img class="fifth"  alt="" src="reviews__review5_photo.jpg" />


        </div>
       
    </section>

    <!-- /reviews -->

    <!-- order info -->

    <section class="order_info_section" >
        <h2 style="font-size:20px" >Order a children's safe <br><b>Shipping and payment</b></h2>
        <div class="info_list" >
            <div class="info_item clearfix" >
                <img src="22.png"  alt="">
                <div class="text_block" >
                    <h4>Delivery</h4>
                    <p>Free delivery in UAE. Delivery period
                        1-3 business days.</p>
                </div>
            </div>
            <div class="info_item clearfix" >
                <img src="11.png"  alt="">
                <div class="text_block" >
                    <h4>Payment </h4>
                    <p>Pay upon delivery!</p>
                </div>
            </div>
            <div class="info_item clearfix" >
                <img src="33.png"  alt="">
                <div class="text_block" >
                    <h4>Quality</h4>
                    <p>Best quality on the market</p>
                </div>
            </div>
        </div>
    </section>

    <!-- /order info -->

    <!-- offer -->

    <section class="offer_section" >
        <div class="title_block" >
            <div class="my-title" >Children</div>
            <div class="my-subtitle" >safe money box</div>
            <div class="lower-title" >best seller</div>
            <div class="lower-subtitle" >best educational toy</div>
        </div>
        <div class="price_block clearfix" >
            <div class="price_item old" >
                <div class="text" >Old price:</div>
                <div class="value" ><?= $oldPriceHtml ?> <?= $currencyDisplayHtml ?></div>
            </div>
            <div class="discount" >
                <div class="text" >SALE</div>
                <div class="value" >-50%</div>
            </div>
            <div class="price_item new" >
                <div class="text" >NEW PRICE:</div>
                <div class="value" ><?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></div>
            </div>
        </div>
        <form id="order_form"  class="order_form"  action="" method="post">
		<?= countryDefault() ?>
            <input class="input"  type="text"  name="name"  placeholder="Name"  required>
            <input class="input"  type="tel"  name="phone"  placeholder="971 55 555 55 55"  required>

            <div class="button_block" >
                <button class="button" >ORDER NOW</button>
            </div>
            <div class="count_block" >
                <div class="count" ><span>Left 10 pcs only!</span></div>
            </div>
        </form>
    </section>

   <center><?= footer('en') ?></center>
</div>
<script src=" https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="previewyoutube.js" ></script>
<script src="owl.carousel.min.js" ></script>
<script src="scripts.js" ></script>

</body>
</html>