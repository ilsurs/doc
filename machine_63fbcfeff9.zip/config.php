<?php

$apiKey = 'CUeKhra60cQHf6V6zqpmFnmKbaHi9JyXUrF6DTBmp5yhtyJAYc12';          // Ключ доступа к API
$offer_id = 5221;         // для каждого оффера свой айди, надо уточнять его в админке или у суппортов
$stream_hid = 'OzEUM35o';     // id потока

$landKey = '93cfa2a42a9091af64e2ac4b5fbc57ab';

$default_main_site = 'http://api.cpa.tl';
$apiSendLeadUrl = 'http://api.cpa.tl/api/lead/send_archive';
$apiGetLeadUrl = 'http://api.cpa.tl/api/lead/feed';

$dataOffers = '{"20897":{"id":20897,"name":"3IN1 Machine","country":{"code":"AE","name":"\u041e\u0410\u042d"},"price":"159","price2":"318","currency":{"code":"AE1","name":"AED"}}}';
$dataOffer = '{"id":20897,"name":"3IN1 Machine","country":{"code":"AE","name":"\u041e\u0410\u042d"},"price":"159","price2":"318","currency":{"code":"AE1","name":"AED"}}';
$is_geo_detect = '1';
$productName = '3IN1 Machine';
$invoice = 'index.php';
$language = 'en';
$push_link = '';

$keitaro_postback = '';

$companyInfo = array('address' => '603140, Нижегородская область, г. Нижний Новгород, пер. Мотальный, д. 4, офис 301', 'detail' => 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ "РК-ТРЕЙД" ОГРН: 1215200002918 ИНН: 5260476009 КПП: 525801001');
$companyInfoEN = array('address' => '129090, Moscow, pereulok Zhivarev, house 8, stroenie 3, flat 16 email: ostrov.prodazh@mail.com Skype: ostrov.prodazh@mail.com', 'detail' => 'OOO "OSTROV PRODAZH" OGRN: 1197746695530 VAT: 7708365555');

$_debug = False; // установите True для вывода дополнительной информации для отладки и поиска ошибок
$pixels = [
    'fb_pixel', 'google_pixel', 'google_adw_pixel', 'tiktok_pixel', 'topmail_pixel', 'vk_pixel', 'yandex_metrika'
];

if(!$apiKey){
    echo 'Ключ доступа к API не определен. Получите в личном кабинете или обратитесь в службу поддержки';
    die;
}

if(!$offer_id){
    echo 'ID оффера не определен';
    die;
}
